const { Transaction, User, Wallet, AuditLog, DepositRequest, GameSetting, GameLog, sequelize } = require('../models');

// Get Pending Recharges (Now Fetching DepositRequests)
exports.getPendingRecharges = async (req, res) => {
    try {
        const recharges = await DepositRequest.findAll({
            where: { status: 'pending' },
            include: [{ model: User, attributes: ['fullName', 'phone'] }]
        });
        res.json(recharges);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
};

// Approve/Reject Transaction (Legacy - kept for backward compatibility if needed)
exports.manageTransaction = async (req, res) => {
    const t = await sequelize.transaction();
    try {
        const { transactionId, status, comment } = req.body; // status: 'completed' or 'rejected'
        const adminId = req.user.user.id;

        const transaction = await Transaction.findByPk(transactionId);
        if (!transaction) {
            await t.rollback();
            return res.status(404).json({ message: 'Transaction not found' });
        }

        if (transaction.status !== 'pending') {
            await t.rollback();
            return res.status(400).json({ message: 'Transaction already processed' });
        }

        transaction.status = status;
        transaction.adminComment = comment;
        await transaction.save({ transaction: t });

        if (status === 'completed' && transaction.type === 'recharge') {
            const wallet = await Wallet.findOne({ where: { userId: transaction.userId } });
            // Multiply by exchange rate if needed
            await wallet.increment('balance', { by: transaction.amount, transaction: t });
        }

        // Audit Log
        await AuditLog.create({
            adminId,
            action: `Transaction ${status}`,
            details: `Transaction ID: ${transactionId}, Amount: ${transaction.amount}`,
            ipAddress: req.ip
        }, { transaction: t });

        await t.commit();
        res.json({ message: `Transaction ${status} successfully` });
    } catch (err) {
        await t.rollback();
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
};

// Get Audit Logs
exports.getAuditLogs = async (req, res) => {
    try {
        const logs = await AuditLog.findAll({
            include: [{ model: User, attributes: ['username'] }],
            order: [['createdAt', 'DESC']]
        });
        res.json(logs);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
};

// Handle Deposit Request (Approve/Reject)
exports.handleDepositRequest = async (req, res) => {
    try {
        const { requestId, action } = req.body; // action: 'approve' | 'reject'
        const depositRequest = await DepositRequest.findByPk(requestId);

        if (!depositRequest) {
            return res.status(404).json({ message: 'Request not found' });
        }

        if (depositRequest.status !== 'pending') {
            return res.status(400).json({ message: 'Request is already processed' });
        }

        if (action === 'approve') {
            // Find User Wallet
            const wallet = await Wallet.findOne({ where: { userId: depositRequest.userId } });
            if (!wallet) {
                return res.status(404).json({ message: 'User wallet not found' });
            }

            // Update Wallet Balance
            wallet.balance = parseFloat(wallet.balance) + parseFloat(depositRequest.amount);
            await wallet.save();

            // Create Transaction Record
            await Transaction.create({
                userId: depositRequest.userId,
                type: 'deposit',
                amount: depositRequest.amount,
                description: 'Deposit Approved by Admin',
                status: 'completed'
            });

            depositRequest.status = 'approved';
        } else if (action === 'reject') {
            depositRequest.status = 'rejected';
        } else {
            return res.status(400).json({ message: 'Invalid action' });
        }

        await depositRequest.save();

        // Log Action
        await AuditLog.create({
            adminId: req.user.user.id,
            action: `Deposit ${action}`,
            details: `Request ID: ${requestId}, Amount: ${depositRequest.amount}`
        });

        res.json({ message: `Deposit request ${action}d successfully`, depositRequest });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
};

// Update Game Status
exports.updateGameStatus = async (req, res) => {
    try {
        const { status } = req.body; // status: 'active' | 'inactive'
        let setting = await GameSetting.findOne({ where: { settingName: 'game_status' } });

        if (!setting) {
            setting = await GameSetting.create({ settingName: 'game_status', settingValue: status });
        } else {
            setting.settingValue = status;
            await setting.save();
        }

        // Log
        await AuditLog.create({
            adminId: req.user.user.id,
            action: 'Update Game Status',
            details: `Status set to ${status}`
        });

        res.json({ message: 'Game status updated', status });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
};

// System Financial Health Check
exports.getSystemFinancials = async (req, res) => {
    try {
        // 1. Authorized Capital Sources

        // A. Approved Deposits
        const totalDeposits = await Transaction.sum('amount', {
            where: { type: 'deposit', status: 'completed' }
        }) || 0;

        // B. Admins/Other

        // C. Game Economy (Net Created Money)
        const totalGameBets = await GameLog.sum('betAmount') || 0;
        const totalGamePayouts = await GameLog.sum('payout') || 0;
        const netGameCreation = totalGamePayouts - totalGameBets;

        const authorizedSupply = totalDeposits + netGameCreation;

        // 2. Actual Liability (User Wallets)
        const totalMainWallet = await Wallet.sum('balance') || 0;
        const totalGameWallet = await Wallet.sum('game_balance') || 0;
        const actualLiability = totalMainWallet + totalGameWallet;

        // 3. Circulation / Volume (Fixed: Use Absolute Value)
        const totalP2PTransfers = Math.abs(await Transaction.sum('amount', {
            where: { type: 'send_money', status: 'completed' }
        }) || 0);

        // 4. Discrepancy
        // Precision handling
        const discrepancy = parseFloat((actualLiability - authorizedSupply).toFixed(2));

        res.json({
            authorized: {
                total_deposits: totalDeposits,
                net_game_creation: netGameCreation,
                total_supply: authorizedSupply
            },
            actual: {
                user_main_balances: totalMainWallet,
                user_game_balances: totalGameWallet,
                total_liability: actualLiability
            },
            volume: {
                p2p_transfers: totalP2PTransfers,
                total_bets: totalGameBets
            },
            health: {
                discrepancy: discrepancy,
                status: discrepancy > 10 ? 'CRITICAL' : (discrepancy < -10 ? 'WARNING' : 'HEALTHY'),
                message: discrepancy > 10
                    ? `Found ৳${discrepancy} fake/unaccounted money!`
                    : (discrepancy < -10 ? `System is deflationary/missing ৳${Math.abs(discrepancy)}` : 'System is Balanced')
            }
        });

    } catch (err) {
        console.error("Audit Error:", err);
        res.status(500).json({ message: 'Server Error during Audit', error: err.toString() });
    }
};
