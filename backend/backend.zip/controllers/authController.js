const { User, Wallet } = require('../models');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

exports.register = async (req, res) => {
    const t = await require('../models').sequelize.transaction();
    try {
        console.log('Register Request Body:', req.body);
        const { fullName, phone, country, password } = req.body;

        // Check if user already exists
        let user = await User.findOne({ where: { phone } });
        if (user) {
            await t.rollback();
            console.log('User already exists');
            return res.status(400).json({ message: 'User already exists with this phone number.' });
        }

        // Generate Username
        const username = fullName.split(' ')[0].toLowerCase() + Math.floor(1000 + Math.random() * 9000);
        console.log('Generated Username:', username);

        // Hash password
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        // Create User
        user = await User.create({
            fullName,
            username,
            phone,
            country,
            password: hashedPassword,
            kycStatus: 'none',
            role: 'user'
        }, { transaction: t });
        console.log('User Created:', user.id);

        // Create Wallet
        await Wallet.create({
            userId: user.id
        }, { transaction: t });
        console.log('Wallet Created');

        await t.commit();

        // Generate JWT
        const payload = {
            user: {
                id: user.id,
                role: user.role
            }
        };

        jwt.sign(
            payload,
            process.env.JWT_SECRET || 'fallback_secret_key_12345',
            { expiresIn: '1d' },
            (err, token) => {
                if (err) throw err;
                res.status(201).json({
                    message: 'User registered successfully',
                    token,
                    user: {
                        id: user.id,
                        username: user.username,
                        role: user.role,
                        fullName: user.fullName
                    }
                });
            }
        );
    } catch (err) {
        await t.rollback();
        console.error('Registration Error:', err);
        res.status(500).json({ message: 'Server Error' });
    }
};

exports.login = async (req, res) => {
    try {
        console.log('Login Request Body:', req.body);
        const { phone, password } = req.body;

        // Check if user exists
        const user = await User.findOne({ where: { phone } });
        if (!user) {
            console.log('User not found for phone:', phone);
            return res.status(400).json({ message: 'Invalid credentials' });
        }
        console.log('User found:', user.username);
        console.log('Stored Password Hash:', user.password);

        // Validate password
        const isMatch = await bcrypt.compare(password, user.password);
        console.log('Password Match Result:', isMatch);

        if (!isMatch) {
            return res.status(400).json({ message: 'Invalid credentials' });
        }

        // Generate JWT
        const payload = {
            user: {
                id: user.id,
                role: user.role
            }
        };

        jwt.sign(
            payload,
            process.env.JWT_SECRET || 'fallback_secret_key_12345',
            { expiresIn: '1d' },
            (err, token) => {
                if (err) throw err;
                res.json({ token, user: { id: user.id, username: user.username, role: user.role, fullName: user.fullName } });
            }
        );
    } catch (err) {
        console.error('Login Error:', err);
        res.status(500).json({ message: 'Server Error' });
    }
};

exports.getMe = async (req, res) => {
    try {
        const user = await User.findByPk(req.user.user.id, {
            attributes: { exclude: ['password'] },
            include: [{ model: Wallet }]
        });
        res.json(user);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
};
