const { GameSetting } = require('../models');

// Get Payment Settings
exports.getPaymentSettings = async (req, res) => {
    try {
        const bkashNumber = await GameSetting.findOne({ where: { settingName: 'bkash_number' } });
        const bankDetails = await GameSetting.findOne({ where: { settingName: 'bank_details' } });

        // Fetch Agent Deposit Numbers
        const depositAgentsSetting = await GameSetting.findOne({ where: { settingName: 'deposit_agents' } });
        const depositAgents = depositAgentsSetting && depositAgentsSetting.settingValue ? JSON.parse(depositAgentsSetting.settingValue) : [];

        res.json({
            bkash_number: bkashNumber ? bkashNumber.settingValue : '',
            bank_details: bankDetails ? bankDetails.settingValue : '',
            deposit_agents: depositAgents
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
};

// Update Payment Settings
exports.updatePaymentSettings = async (req, res) => {
    try {
        const { bkash_number, bank_details } = req.body;

        if (bkash_number) {
            await GameSetting.upsert({ settingName: 'bkash_number', settingValue: bkash_number, description: 'Admin Bkash Number' });
        }
        if (bank_details) {
            await GameSetting.upsert({ settingName: 'bank_details', settingValue: bank_details, description: 'Bank Account Details' });
        }

        res.json({ message: 'Settings updated' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
};
