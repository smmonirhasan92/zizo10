const { Transaction, Wallet, User, sequelize } = require('../models');

// Methods for Payment Settings moved to settingsController.js


// Methods moved to walletController.js


// Get Pending Transactions (Admin)
exports.getPendingTransactions = async (req, res) => {
    try {
        const { type } = req.query;
        const whereClause = { status: 'pending' };
        if (type) whereClause.type = type;

        const transactions = await Transaction.findAll({
            where: whereClause,
            include: [{ model: User, attributes: ['fullName', 'phone', 'username'] }],
            order: [['createdAt', 'ASC']]
        });
        res.json(transactions);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
};

// Get ALL Transactions (Admin History)
exports.getAllTransactions = async (req, res) => {
    try {
        const { userId } = req.query;
        const whereClause = {};
        if (userId) whereClause.userId = userId;

        const transactions = await Transaction.findAll({
            where: whereClause,
            include: [{ model: User, attributes: ['fullName', 'phone'] }],
            order: [['createdAt', 'DESC']]
        });
        res.json(transactions);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
};

// Assign Transaction to Agent (Admin)
// Assign Transaction to Agent (Admin)
exports.assignTransaction = async (req, res) => {
    const t = await sequelize.transaction();
    try {
        const { transactionId, agentId } = req.body;

        const transaction = await Transaction.findByPk(transactionId, { transaction: t });
        if (!transaction) {
            await t.rollback();
            return res.status(404).json({ message: 'Transaction not found' });
        }

        if (transaction.assignedAgentId) {
            await t.rollback();
            return res.status(400).json({ message: 'Transaction already assigned' });
        }

        transaction.assignedAgentId = agentId;
        await transaction.save({ transaction: t });

        // CRITICAL: Credit Agent Wallet with the amount to be processed
        // For 'send_money' and 'mobile_recharge', the amount is stored as negative (deduction from user).
        // We need to give the positive equivalent to the agent so they can spend it/send it.
        if (transaction.type === 'send_money' || transaction.type === 'mobile_recharge') {
            const amountToCredit = Math.abs(parseFloat(transaction.amount));

            const agentWallet = await Wallet.findOne({ where: { userId: agentId } }, { transaction: t });
            if (agentWallet) {
                await agentWallet.increment('balance', { by: amountToCredit, transaction: t });

                // Optional: Log a 'fund_in' transaction for the agent so they know why they got money
                // Or rely on the Assigned Task list to explain it.
                // Let's create a 'received_for_task' record for clarity in history if we want, 
                // but for now, just updating balance as requested.
            }
        }

        await t.commit();
        res.json({ message: 'Transaction assigned & Funds transferred to Agent', transaction });
    } catch (err) {
        await t.rollback();
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
};

// Get Assigned Transactions (Agent)
exports.getAssignedTransactions = async (req, res) => {
    try {
        const agentId = req.user.user.id;
        const transactions = await Transaction.findAll({
            where: { assignedAgentId: agentId, status: 'pending' },
            include: [{ model: User, attributes: ['fullName', 'phone'] }],
            order: [['createdAt', 'ASC']]
        });
        res.json(transactions);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
};

// Complete Transaction (Agent/Admin)
exports.completeTransaction = async (req, res) => {
    const t = await sequelize.transaction();
    try {
        const { transactionId, status, comment, bonusAmount, receivedByAgentId } = req.body;
        const agentId = req.user.user.id;

        const transaction = await Transaction.findOne({
            where: { id: transactionId },
            transaction: t
        });

        if (!transaction) {
            await t.rollback();
            return res.status(404).json({ message: 'Transaction not found' });
        }

        // Check if user is agent and if transaction is assigned to them (Only for Agents)
        if (req.user.user.role === 'agent') {
            if (transaction.assignedAgentId !== agentId) {
                await t.rollback();
                return res.status(404).json({ message: 'Transaction not assigned to you' });
            }
        }

        if (transaction.status !== 'pending') {
            await t.rollback();
            return res.status(400).json({ message: 'Transaction already processed' });
        }

        console.log(`Processing transaction ${transactionId} as ${status}`);

        transaction.status = status; // completed
        transaction.adminComment = comment || 'Processed by System';

        // Admin Updates (Bonus / Agent Tagging)
        if (bonusAmount) transaction.bonusAmount = parseFloat(bonusAmount);
        if (receivedByAgentId) transaction.receivedByAgentId = receivedByAgentId;

        await transaction.save({ transaction: t });

        if (status === 'completed') {
            if (transaction.type === 'add_money' || transaction.type === 'recharge') {
                const wallet = await Wallet.findOne({ where: { userId: transaction.userId } }, { transaction: t });

                let finalAmount = parseFloat(transaction.amount);
                if (bonusAmount) finalAmount += parseFloat(bonusAmount);

                await wallet.increment('balance', { by: finalAmount, transaction: t });

                // CRITICAL: Debit Agent Wallet if they received the funds
                if (transaction.receivedByAgentId) {
                    const agentWallet = await Wallet.findOne({ where: { userId: transaction.receivedByAgentId } }, { transaction: t });
                    if (agentWallet) {
                        // Debit the amount (without bonus, just the raw amount they received)
                        await agentWallet.decrement('balance', { by: parseFloat(transaction.amount), transaction: t });

                        // Log for Agent?
                        // Optional, but balance update is key.
                    }
                }
            }

            // --- Agent Commission Logic ---
            if (req.user.user.role === 'agent') {
                const agent = await User.findByPk(agentId, { transaction: t });
                const commissionRate = parseFloat(agent.commissionRate || 0);

                if (commissionRate > 0) {
                    const commissionAmount = (Math.abs(parseFloat(transaction.amount)) * commissionRate) / 100;

                    if (commissionAmount > 0) {
                        // Credit Agent Wallet
                        const agentWallet = await Wallet.findOne({ where: { userId: agentId } }, { transaction: t });
                        await agentWallet.increment('balance', { by: commissionAmount, transaction: t });

                        // Log Commission Transaction
                        await Transaction.create({
                            userId: agentId,
                            type: 'commission',
                            amount: commissionAmount,
                            status: 'completed',
                            recipientDetails: `Commission for TrxID: ${transactionId} (${commissionRate}%)`
                        }, { transaction: t });

                        console.log(`Commission of ${commissionAmount} credited to Agent ${agent.username}`);
                    }
                }
            }
        }

        await t.commit();
        res.json({ message: 'Transaction completed successfully' });
    } catch (err) {
        await t.rollback();
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
};

// Get History
exports.getHistory = async (req, res) => {
    try {
        const userId = req.user.user.id;
        const { Op } = require('sequelize');

        const whereClause = {
            [Op.or]: [
                { userId: userId },
                { assignedAgentId: userId },
                { receivedByAgentId: userId }
            ]
        };

        const transactions = await Transaction.findAll({
            where: whereClause,
            order: [['createdAt', 'DESC']]
        });
        res.json(transactions);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
};
