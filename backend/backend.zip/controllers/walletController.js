const { Wallet, Transaction, User, DepositRequest, sequelize } = require('../models');

// Get Wallet Balance
exports.getBalance = async (req, res) => {
    try {
        const wallet = await Wallet.findOne({ where: { userId: req.user.user.id } });
        if (!wallet) return res.status(404).json({ message: 'Wallet not found' });
        res.json(wallet);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
};

// Request Recharge (Upload proof)
exports.requestRecharge = async (req, res) => {
    try {
        const { amount } = req.body;
        const proofImage = req.file ? req.file.path : null;

        if (!proofImage) {
            return res.status(400).json({ message: 'Proof image is required' });
        }

        const depositRequest = await DepositRequest.create({
            userId: req.user.user.id,
            amount,
            proofImage,
            status: 'pending'
        });

        res.status(201).json({ message: 'Recharge request submitted successfully', depositRequest });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
};

// Activate Wallet (KYC Upload)
exports.activateWallet = async (req, res) => {
    try {
        const kycImage = req.file ? req.file.path : null;
        if (!kycImage) {
            return res.status(400).json({ message: 'KYC image is required' });
        }

        await User.update({ kycStatus: 'pending', kycImage }, { where: { id: req.user.user.id } });
        res.json({ message: 'Activation request submitted' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
};
// Request Send Money (Cash Out) - User -> Agent Flow
exports.sendMoney = async (req, res) => {
    const t = await sequelize.transaction();
    try {
        const { amount, recipientPhone, method, accountType } = req.body;
        const senderId = req.user.user.id;
        const parsedAmount = parseFloat(amount);

        // Find Sender Wallet
        const senderWallet = await Wallet.findOne({ where: { userId: senderId } }, { transaction: t });
        if (senderWallet.balance < parsedAmount) {
            await t.rollback();
            return res.status(400).json({ message: 'Insufficient balance' });
        }

        // Deduct from Sender immediately
        await senderWallet.decrement('balance', { by: parsedAmount, transaction: t });

        // Create Transaction Record (Pending)
        await Transaction.create({
            userId: senderId,
            type: 'send_money',
            amount: -parsedAmount,
            status: 'pending',
            recipientDetails: `To: ${recipientPhone} (${method}) - ${accountType || 'Personal'}`
        }, { transaction: t });

        await t.commit();
        res.json({ message: 'Send Money request submitted. Agent will process shortly.' });
    } catch (err) {
        await t.rollback();
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
};

// Request Mobile Recharge
exports.mobileRecharge = async (req, res) => {
    const t = await sequelize.transaction();
    try {
        const { amount, recipientPhone, operator } = req.body;
        const senderId = req.user.user.id;
        const parsedAmount = parseFloat(amount);

        // Find Sender Wallet
        const senderWallet = await Wallet.findOne({ where: { userId: senderId } }, { transaction: t });
        if (senderWallet.balance < parsedAmount) {
            await t.rollback();
            return res.status(400).json({ message: 'Insufficient balance' });
        }

        // Deduct immediately
        await senderWallet.decrement('balance', { by: parsedAmount, transaction: t });

        // Create Transaction
        await Transaction.create({
            userId: senderId,
            type: 'mobile_recharge',
            amount: -parsedAmount,
            status: 'pending',
            recipientDetails: `${operator} - ${recipientPhone}`
        }, { transaction: t });

        await t.commit();
        res.json({ message: 'Recharge request submitted.' });
    } catch (err) {
        await t.rollback();
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
};

// Add Money Request (User)
exports.addMoney = async (req, res) => {
    try {
        const { amount, method, transactionId } = req.body;
        const userId = req.user.user.id;

        // Handle File Upload
        let proofImage = null;
        if (req.file) {
            proofImage = req.file.path; // Multer saves path here
        }

        const transaction = await Transaction.create({
            userId,
            type: 'add_money',
            amount: parseFloat(amount),
            status: 'pending',
            recipientDetails: `Method: ${method}, Sender: ${transactionId}`,
            proofImage
        });

        res.status(201).json({ message: 'Add money request submitted', transaction });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
};
// Transfer: Main -> Game
exports.transferToGame = async (req, res) => {
    const t = await sequelize.transaction();
    try {
        const { amount } = req.body;
        const userId = req.user.user.id;
        const parsedAmount = parseFloat(amount);

        if (isNaN(parsedAmount) || parsedAmount <= 0) {
            return res.status(400).json({ message: 'Invalid amount' });
        }

        const wallet = await Wallet.findOne({ where: { userId } }, { transaction: t });
        if (wallet.balance < parsedAmount) {
            await t.rollback();
            return res.status(400).json({ message: 'Insufficient Main Balance' });
        }

        // Deduct from Main, Add to Game
        await wallet.decrement('balance', { by: parsedAmount, transaction: t });
        await wallet.increment('game_balance', { by: parsedAmount, transaction: t });

        // Log Transaction
        await Transaction.create({
            userId,
            type: 'transfer_game',
            amount: -parsedAmount, // Negative for Main Wallet view? Actually internal transfer.
            status: 'completed',
            recipientDetails: 'Transfer to Game Wallet'
        }, { transaction: t });

        await t.commit();
        res.json({ message: 'Transfer successful', newMainBalance: wallet.balance - parsedAmount, newGameBalance: wallet.game_balance + parsedAmount });
    } catch (err) {
        await t.rollback();
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
};

// Transfer: Game -> Main
exports.transferToMain = async (req, res) => {
    const t = await sequelize.transaction();
    try {
        const { amount } = req.body;
        const userId = req.user.user.id;
        const parsedAmount = parseFloat(amount);

        if (isNaN(parsedAmount) || parsedAmount <= 0) {
            return res.status(400).json({ message: 'Invalid amount' });
        }

        const wallet = await Wallet.findOne({ where: { userId } }, { transaction: t });
        if (wallet.game_balance < parsedAmount) {
            await t.rollback();
            return res.status(400).json({ message: 'Insufficient Game Balance' });
        }

        // Deduct from Game, Add to Main
        await wallet.decrement('game_balance', { by: parsedAmount, transaction: t });
        await wallet.increment('balance', { by: parsedAmount, transaction: t });

        // Log Transaction
        await Transaction.create({
            userId,
            type: 'transfer_main',
            amount: parsedAmount,
            status: 'completed',
            recipientDetails: 'Transfer from Game Wallet'
        }, { transaction: t });

        await t.commit();
        res.json({ message: 'Transfer successful', newMainBalance: wallet.balance + parsedAmount, newGameBalance: wallet.game_balance - parsedAmount });
    } catch (err) {
        await t.rollback();
        console.error(err);
        res.status(500).json({ message: 'Server Error' });
    }
};
