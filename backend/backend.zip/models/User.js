const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const User = sequelize.define('User', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    fullName: {
        type: DataTypes.STRING,
        allowNull: false
    },
    username: {
        type: DataTypes.STRING,
        unique: true,
        allowNull: false
    },
    phone: {
        type: DataTypes.STRING,
        unique: true,
        allowNull: false
    },
    country: {
        type: DataTypes.STRING,
        allowNull: false
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false
    },
    role: {
        type: DataTypes.ENUM('super_admin', 'employee_admin', 'agent', 'user'),
        defaultValue: 'user'
    },
    photoUrl: {
        type: DataTypes.STRING,
        allowNull: true
    },
    commissionRate: {
        type: DataTypes.DECIMAL(5, 2), // Percentage, e.g., 5.00
        defaultValue: 0.00,
        allowNull: false
    },
    kycStatus: {
        type: DataTypes.ENUM('pending', 'approved', 'rejected', 'none'),
        defaultValue: 'none'
    },
    kycImage: {
        type: DataTypes.STRING,
        allowNull: true
    }
}, {
    timestamps: true
});

module.exports = User;
