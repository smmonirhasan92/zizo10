const express = require('express');
const router = express.Router();
const transactionController = require('../controllers/transactionController');
const settingsController = require('../controllers/settingsController');
const walletController = require('../controllers/walletController'); // Import walletController
const authMiddleware = require('../middleware/authMiddleware');
const upload = require('../middleware/uploadMiddleware'); // Import upload middleware

router.post('/send', authMiddleware, walletController.sendMoney);
router.post('/mobile-recharge', authMiddleware, walletController.mobileRecharge);
router.get('/history', authMiddleware, transactionController.getHistory);

router.post('/add-money', authMiddleware, upload.single('proofImage'), walletController.addMoney);

// Sys Settings
router.get('/settings/payment', authMiddleware, settingsController.getPaymentSettings);
router.put('/settings/payment', authMiddleware, (req, res, next) => {
    // Basic Admin Check Inline
    if (req.user.user.role !== 'admin' && req.user.user.role !== 'super_admin') {
        return res.status(403).json({ message: 'Access denied' });
    }
    next();
}, settingsController.updatePaymentSettings);

// Admin/Agent Routes (Inline middleware for simplicity or move to separate file later)
const checkRole = (roles) => (req, res, next) => {
    if (!roles.includes(req.user.user.role)) {
        return res.status(403).json({ message: 'Access denied' });
    }
    next();
};

router.get('/pending', authMiddleware, checkRole(['admin', 'super_admin', 'employee_admin']), transactionController.getPendingTransactions);
router.get('/all', authMiddleware, checkRole(['admin', 'super_admin']), transactionController.getAllTransactions);
router.post('/assign', authMiddleware, checkRole(['admin', 'super_admin', 'employee_admin']), transactionController.assignTransaction);
router.get('/assigned', authMiddleware, checkRole(['agent', 'admin', 'super_admin']), transactionController.getAssignedTransactions);
router.post('/complete', authMiddleware, checkRole(['agent', 'admin', 'super_admin']), transactionController.completeTransaction);

module.exports = router;
