const express = require('express');
const router = express.Router();
const walletController = require('../controllers/walletController');
const authMiddleware = require('../middleware/authMiddleware');
const multer = require('multer');
const path = require('path');

// Multer Config
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});
const upload = multer({ storage });

// Transfer Routes
router.post('/transfer/game', authMiddleware, walletController.transferToGame);
router.post('/transfer/main', authMiddleware, walletController.transferToMain);

router.get('/balance', authMiddleware, walletController.getBalance);
router.post('/recharge', authMiddleware, upload.single('proofImage'), walletController.requestRecharge);
router.post('/activate', authMiddleware, upload.single('kycImage'), walletController.activateWallet);

module.exports = router;
